# MNGL
Python API interface for MNGL Bill - https://www.mngl.in/onlinebill/
This library will use your MNGL BP ID and get the current MNGL bill details.

How to install
--------------

    $ pip install .
